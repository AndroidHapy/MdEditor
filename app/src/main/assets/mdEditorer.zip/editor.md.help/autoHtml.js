// md.help/autoHtml, v1.0.0 
// auth zjl	
//markDown转HTMl的方法
function mdToHml(){

	//先对容器初始化，在需要展示的容器中创建textarea隐藏标签，
	$("#editormd-preview").html('<textarea id="previewArea" style="display:none;"></textarea>');
	var content=$("#mddoc").val();//获取需要转换的内容
	$("#previewArea").val(content);//将需要转换的内容加到转换后展示容器的textarea隐藏标签中

	//转换开始,第一个参数是上面的div的id
	editormd.markdownToHTML("editormd-preview", {
		path : 'editor.md/lib/',
		htmlDecode: "style,script,iframe", //可以过滤标签解码
		emoji: true,
		taskList:true,
	    watch : true,                // 实时预览
        tocm            : true,       // Using [TOCM]
		toc  : true,                  // Using [TOC]
        tex : true,                   // 开启科学公式TeX语言支持，默认关闭
        flowChart : true,             // 开启流程图支持，默认关闭
        sequenceDiagram : true,       // 开启时序/序列图支持，默认关闭,
		
		toolbar  : false,           //关闭工具栏
	}); 
	
	mdAutoToc();
//	setTimeout( function(){
//	}, 0 * 1000 );//延迟1000毫米
	
}

// 自动生成标题 
function mdAutoToc(){
	   
	$(document).ready(function(e) {
	    // div的id为 previewArea
    	$("#editormd-preview").children().each(function(index, element) {
    		var tagName=$(this).get(0).tagName;
			var lab = tagName.substr(0,1);   // 标题
			var level=tagName.substr(1,2);   // 标题等级
			
    		if(lab.toUpperCase()=="H" ){  // 过滤
				if(!isNaN(level)){
					var contentH=$(this).text();//获取内容
					var markid=$(this).attr("id"); // 获取标题id
					
					//$(this).attr("id",markid);//为当前h标签设置id
					// <a> 属性
					var classtmp = 	" class=\"toc-level-" + level +  "\" ";
					var hreftmp = " href=\"#" + markid + "\" ";
					var leveltmp = " level=\"" + level + "\" ";
					// <li>
					var libtmp = "<li> <a " + classtmp + hreftmp + leveltmp + " > " + contentH + "</a> </li>";
				    // 内容追加 
					$(".menu-toc").append(libtmp);//在目标DIV中添加内容,div的class为menu-toc  
				} 
    		}  
    	});
    });
 
}